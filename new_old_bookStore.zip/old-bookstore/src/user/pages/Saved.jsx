import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Saved = () => {
  const [saved, setSaved] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("saved")) || [];
    setSaved(data);
  }, []);

  const moveToCart = (book) => {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    if (!cart.find(item => item.id === book.id)) {
      cart.push({ ...book, qty: 1 });
      localStorage.setItem("cart", JSON.stringify(cart));
    }
    const updated = saved.filter(item => item.id !== book.id);
    setSaved(updated);
    localStorage.setItem("saved", JSON.stringify(updated));
    alert("Moved to cart ✅");
  };

  const removeItem = (id) => {
    const updated = saved.filter(item => item.id !== id);
    setSaved(updated);
    localStorage.setItem("saved", JSON.stringify(updated));
  };

  return (
    <div style={{ padding: "30px" }}>
      <h2>❤️ Saved for Later</h2>
      {saved.length === 0 ? <p>No saved books.</p> : (
        saved.map(book => (
          <div key={book.id} style={{ border: "1px solid #ccc", marginBottom: "10px", padding: "10px" }}>
            <h4>{book.title}</h4>
            <p>Author: {book.author}</p>
            <p>Price: ₹{book.price}</p>
            <button onClick={() => moveToCart(book)}>🛒 Move to Cart</button>
            <button onClick={() => removeItem(book.id)} style={{ marginLeft: "10px", color: "red" }}>Remove</button>
          </div>
        ))
      )}
    </div>
  );
};

export default Saved;
