import { useEffect, useState } from "react";
import axios from "axios";

const Home = () => {
  const [banners, setBanners] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3001/banners").then((res) => {
      setBanners(res.data);
    });
  }, []);

  return (
    <div className="container mx-auto px-4 py-10">
      <h2 className="text-3xl font-bold text-center mb-8">🎉 Welcome to Old Book Store</h2>

      {/* Carousel Section */}
      {banners.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          {/* LEFT - Banner Content */}
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-purple-700">{banners[0].title}</h3>
            <p className="text-gray-700 text-lg">{banners[0].subtitle}</p>
            <button className="bg-purple-700 text-white px-4 py-2 rounded hover:bg-purple-800 transition">
              📚 Explore Books
            </button>
          </div>

          {/* RIGHT - Carousel Image */}
          <div className="w-full h-72 overflow-hidden rounded-lg shadow-md">
            <img
              src={banners[0].image}
              alt="Banner"
              className="object-cover w-full h-full animate-fadeIn"
            />
          </div>
        </div>
      ) : (
        <p className="text-center text-gray-500">Loading banner...</p>
      )}

      {/* Section: About or Categories */}
      <div className="mt-16">
        <h3 className="text-xl font-semibold mb-4">🧾 Why Choose Us?</h3>
        <ul className="list-disc list-inside text-gray-600 space-y-1">
          <li>Affordable old books from top categories 📘</li>
          <li>Quick checkout and fast delivery 🚚</li>
          <li>Admin-managed inventory with regular updates ✅</li>
        </ul>
      </div>
    </div>
  );
};

export default Home;
