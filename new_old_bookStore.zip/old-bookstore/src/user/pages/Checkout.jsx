import React from 'react';

const Checkout = () => {
  const handleConfirm = () => {
    localStorage.removeItem("cart");
    alert("✅ Order Confirmed! Thank you for shopping!");
    window.location.href = "/";
  };

  return (
    <div style={{ padding: "40px", textAlign: "center" }}>
      <h2>🧾 Confirm Order</h2>
      <p>Payment method: (For demo, no real payment)</p>
      <button onClick={handleConfirm} style={{ marginTop: "20px", padding: "10px 20px" }}>✔ Confirm Order</button>
    </div>
  );
};

export default Checkout;
