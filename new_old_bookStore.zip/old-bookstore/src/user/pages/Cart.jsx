import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Cart = () => {
  const [cart, setCart] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const savedCart = JSON.parse(localStorage.getItem("cart")) || [];
    setCart(savedCart.map(item => ({ ...item, qty: item.qty || 1 })));
  }, []);

  // ➕ Increase quantity
  const increaseQty = (id) => {
    const updated = cart.map(item => item.id === id ? { ...item, qty: item.qty + 1 } : item);
    setCart(updated);
    localStorage.setItem("cart", JSON.stringify(updated));
  };

  // ➖ Decrease quantity
  const decreaseQty = (id) => {
    const updated = cart.map(item => {
      if (item.id === id && item.qty > 1) {
        return { ...item, qty: item.qty - 1 };
      }
      return item;
    });
    setCart(updated);
    localStorage.setItem("cart", JSON.stringify(updated));
  };

  // ❌ Remove item
  const removeItem = (id) => {
    const updated = cart.filter(item => item.id !== id);
    setCart(updated);
    localStorage.setItem("cart", JSON.stringify(updated));
  };

  // 💰 Total Price
  const totalPrice = cart.reduce((total, item) => total + item.price * item.qty, 0);

  return (
    <div style={{ padding: "20px" }}>
      <h2>🛒 Your Cart</h2>
      {cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          {cart.map(item => (
            <div key={item.id} style={{ border: "1px solid #ccc", margin: "10px 0", padding: "10px" }}>
              <h4>{item.title}</h4>
              <p>Price: ₹{item.price} × {item.qty} = ₹{item.price * item.qty}</p>
              <button onClick={() => decreaseQty(item.id)}>-</button>
              <span style={{ margin: "0 10px" }}>{item.qty}</span>
              <button onClick={() => increaseQty(item.id)}>+</button>
              <button onClick={() => removeItem(item.id)} style={{ marginLeft: "20px", color: "red" }}>Remove</button>
            </div>
          ))}
          <h3>Total: ₹{totalPrice}</h3>
          <button onClick={() => navigate('/checkout')} style={{ marginTop: "10px", padding: "10px 20px" }}>✅ Checkout</button>
        </>
      )}
    </div>
  );
};

export default Cart;
