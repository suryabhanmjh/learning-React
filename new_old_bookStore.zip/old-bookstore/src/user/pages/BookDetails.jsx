import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const BookDetails = () => {
    const { id } = useParams();
    const [book, setBook] = useState(null);

    useEffect(() => {
        axios.get(`http://localhost:3001/books/${id}`)
            .then(res => setBook(res.data))
            .catch(err => console.error("Failed to fetch book", err));
    }, [id]);

    const addToCart = () => {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        const already = cart.find(item => item.id === book.id);
        if (!already) {
            cart.push(book);
            localStorage.setItem("cart", JSON.stringify(cart));
            alert("Added to cart ✅");
        } else {
            alert("Already in cart ❗");
        }
    };

    const saveForLater = () => {
        const saved = JSON.parse(localStorage.getItem("saved")) || [];
        const alreadySaved = saved.find(item => item.id === book.id);
        if (!alreadySaved) {
            saved.push(book);
            localStorage.setItem("saved", JSON.stringify(saved));
            alert("❤️ Saved for later!");
        } else {
            alert("Already saved!");
        }
    };


    if (!book) return <p>Loading...</p>;

    return (
        <div style={{ padding: "40px", maxWidth: "600px", margin: "auto" }}>
            <img src={book.image} alt={book.title} style={{ width: "100%", borderRadius: "10px" }} />
            <h2>{book.title}</h2>
            <p><b>Author:</b> {book.author}</p>
            <p><b>Category:</b> {book.category}</p>
            <p><b>Description:</b> {book.description}</p>
            <p><b>Price:</b> ₹{book.price}</p>
            <button onClick={addToCart} style={{ padding: "10px 20px", marginTop: "20px" }}>🛒 Add to Cart</button>
            <button onClick={saveForLater} style={{ padding: "10px 20px", marginTop: "10px", backgroundColor: "#f39c12", color: "white" }}>
                ❤️ Save for Later
            </button>

        </div>
    );
};

export default BookDetails;
