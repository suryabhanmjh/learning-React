import { useEffect } from "react";
import { useNavigate, Outlet, NavLink } from "react-router-dom";

const AdminLayout = () => {
  const navigate = useNavigate();

  // 🔐 Check admin auth on load
  useEffect(() => {
    const isLoggedIn = localStorage.getItem("adminLoggedIn");
    if (!isLoggedIn) {
      navigate("/admin/login");
    }
  }, [navigate]);

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="w-64 bg-purple-800 text-white min-h-screen shadow-lg">
        <div className="p-6 border-b border-purple-700">
          <h2 className="text-xl font-bold">📚 Admin Dashboard</h2>
        </div>
        <nav className="p-4 space-y-3">
          <NavLink to="/admin" end className={navClass}>
            🏠 Dashboard
          </NavLink>
          <NavLink to="/admin/panel" className={navClass}>
            📘 Manage Books
          </NavLink>
          <NavLink to="/admin/banners" className={navClass}>
            🖼️ Banners
          </NavLink>
          <NavLink to="/admin/logout" className={navClass}>
            🚪 Logout
          </NavLink>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 bg-gray-50 overflow-y-auto">
        <Outlet />
      </main>
    </div>
  );
};

const navClass = ({ isActive }) =>
  `block px-4 py-2 rounded hover:bg-purple-700 transition ${
    isActive ? "bg-purple-700 font-semibold" : "bg-purple-600"
  }`;

export default AdminLayout;
