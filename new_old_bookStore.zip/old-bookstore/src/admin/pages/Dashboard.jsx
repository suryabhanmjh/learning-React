const Dashboard = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">📊 Admin Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow hover:shadow-md transition">
          <h2 className="text-xl font-semibold text-purple-700">📚 Total Books</h2>
          <p className="text-3xl font-bold mt-2">124</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow hover:shadow-md transition">
          <h2 className="text-xl font-semibold text-purple-700">🖼️ Total Banners</h2>
          <p className="text-3xl font-bold mt-2">5</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow hover:shadow-md transition">
          <h2 className="text-xl font-semibold text-purple-700">👤 Logged in Admin</h2>
          <p className="text-xl mt-2 text-gray-600">sumangpt9876@gmail.com</p>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
