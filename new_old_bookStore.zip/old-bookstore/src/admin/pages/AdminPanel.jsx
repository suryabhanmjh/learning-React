import React, { useState } from 'react';
import axios from 'axios';


const AdminPanel = () => {
  const [form, setForm] = useState({
    title: '',
    author: '',
    category: '',
    price: '',
    description: '',
    image: ''
  });

  const [banner, setBanner] = useState({
    title: '',
    subtitle: '',
    image: ''
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleBannerChange = (e) => {
    setBanner({ ...banner, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:3001/books', {
        ...form,
        price: Number(form.price)
      });
      alert('✅ Book added successfully!');
      setForm({
        title: '',
        author: '',
        category: '',
        price: '',
        description: '',
        image: ''
      });
    } catch (err) {
      alert('❌ Failed to add book');
    }
  };

  const handleBannerSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:3001/banners', banner);
      alert('✅ Banner uploaded!');
      setBanner({
        title: '',
        subtitle: '',
        image: ''
      });
    } catch (err) {
      alert('❌ Failed to upload banner');
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-8">
      <h2 className="text-2xl font-bold mb-4">📚 Admin Panel - Add New Book</h2>
      <form onSubmit={handleSubmit} className="bg-white shadow-md rounded-lg p-6 mb-8">
        <input name="title" placeholder="Title" value={form.title} onChange={handleChange} required className="input mb-3" />
        <input name="author" placeholder="Author" value={form.author} onChange={handleChange} required className="input mb-3" />
        <input name="category" placeholder="Category (e.g. Programming)" value={form.category} onChange={handleChange} required className="input mb-3" />
        <input name="price" type="number" placeholder="Price" value={form.price} onChange={handleChange} required className="input mb-3" />
        <input name="image" placeholder="Image URL" value={form.image} onChange={handleChange} required className="input mb-3" />
        <textarea name="description" placeholder="Description" value={form.description} onChange={handleChange} required className="input mb-3" />
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">➕ Add Book</button>
      </form>
      <h2 className="text-2xl font-bold mb-4">🖼️ Upload Home Banner</h2>
      <form onSubmit={handleBannerSubmit} className="bg-white shadow-md rounded-lg p-6">
        <input name="title" placeholder="Banner Title" value={banner.title} onChange={handleBannerChange} required className="input mb-3" />
        <input name="subtitle" placeholder="Banner Subtitle" value={banner.subtitle} onChange={handleBannerChange} required className="input mb-3" />
        <input name="image" placeholder="Banner Image URL" value={banner.image} onChange={handleBannerChange} required className="input mb-3" />
        <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition">Upload Banner</button>
      </form>
    </div>
  );
};

export default AdminPanel;
