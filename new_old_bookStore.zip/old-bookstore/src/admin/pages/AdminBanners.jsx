import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AdminBanners = () => {
  const [banner, setBanner] = useState({
    title: '',
    desc: '',
    image: ''
  });

  const [banners, setBanners] = useState([]);

  const handleChange = (e) => {
    setBanner({ ...banner, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:3001/banners', banner);
    alert('✅ Banner Added!');
    setBanner({ title: '', desc: '', image: '' });
    fetchBanners();
  };

  const fetchBanners = async () => {
    const res = await axios.get('http://localhost:3001/banners');
    setBanners(res.data);
  };

  useEffect(() => {
    fetchBanners();
  }, []);

  return (
    <div style={{ padding: '30px', maxWidth: '600px', margin: 'auto' }}>
      <h2>🎯 Admin - Add Banner</h2>
      <form onSubmit={handleSubmit}>
        <input name="title" placeholder="Title" value={banner.title} onChange={handleChange} required /><br /><br />
        <input name="desc" placeholder="Description" value={banner.desc} onChange={handleChange} required /><br /><br />
        <input name="image" placeholder="Image URL" value={banner.image} onChange={handleChange} required /><br /><br />
        <button type="submit">➕ Add Banner</button>
      </form>

      <hr />
      <h3>📜 All Banners</h3>
      {banners.map((b) => (
        <div key={b.id} style={{ marginBottom: '15px', border: '1px solid #ccc', padding: '10px' }}>
          <h4>{b.title}</h4>
          <p>{b.desc}</p>
          <img src={b.image} alt="banner" style={{ width: '100%', maxHeight: '180px', objectFit: 'cover' }} />
        </div>
      ))}
    </div>
  );
};

export default AdminBanners;
