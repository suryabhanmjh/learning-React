import React, { useEffect, useState } from 'react';
import axios from 'axios';

const DynamicCarousel = () => {
  const [banners, setBanners] = useState([]);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    axios.get("http://localhost:3001/banners")
      .then(res => setBanners(res.data))
      .catch(err => console.log("Banner load error", err));
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex(prev => (prev + 1) % banners.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [banners]);

  if (banners.length === 0) return <p>Loading banners...</p>;

  const banner = banners[index];

  return (
    <div style={{
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '40px',
      maxWidth: '1000px',
      margin: 'auto',
      borderRadius: '10px',
      background: '#f2f2f2',
      minHeight: '300px',
      boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
    }}>
      {/* LEFT - Text */}
      <div style={{ flex: 1, paddingRight: '30px' }}>
        <h2>{banner.title}</h2>
        <p style={{ fontSize: '18px', color: '#555' }}>{banner.desc}</p>
        <button style={{
          marginTop: '20px',
          padding: '10px 20px',
          background: '#007bff',
          color: '#fff',
          border: 'none',
          borderRadius: '5px',
          cursor: 'pointer'
        }}>
          📚 Explore Now
        </button>
      </div>

      {/* RIGHT - Book Image */}
      <div style={{ flex: 1, textAlign: 'center' }}>
        <img src={banner.image} alt="Book" style={{
          width: '80%',
          height: 'auto',
          maxHeight: '280px',
          objectFit: 'contain',
          borderRadius: '10px'
        }} />
      </div>
    </div>
  );
};

export default DynamicCarousel;
