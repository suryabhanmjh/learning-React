import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="bg-purple-700 text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold">
          <Link to="/">📚 OldBookStore</Link>
        </h1>
        <ul className="flex gap-4 text-lg">
          <li><Link to="/" className="hover:text-yellow-300">Home</Link></li>
          <li><Link to="/books" className="hover:text-yellow-300">Books</Link></li>
          <li><Link to="/saved" className="hover:text-yellow-300">❤️ Saved</Link></li>
          <li><Link to="/cart" className="hover:text-yellow-300">🛒 Cart</Link></li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
