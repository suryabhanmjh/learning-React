import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Layouts
import UserLayout from './layouts/UserLayout';
import AdminLayout from './layouts/AdminLayout';

// Admin Pages
import AdminLogin from './admin/pages/AdminLogin';
import AdminPanel from './admin/pages/AdminPanel';
import AdminBanners from './admin/pages/AdminBanners';
import AdminLogout from './admin/pages/AdminLogout';
import Dashboard from './admin/pages/Dashboard';

// User Pages
import Home from './user/pages/Home';
import Books from './user/pages/Books';
import BookDetails from './user/pages/BookDetails';
import Cart from './user/pages/Cart';
import Checkout from './user/pages/Checkout';
import Saved from './user/pages/Saved';

function App() {
  return (
    <Router>
      <Routes>
        {/* User Side */}
        <Route element={<UserLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/books" element={<Books />} />
          <Route path="/book/:id" element={<BookDetails />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/saved" element={<Saved />} />
        </Route>

        {/* Admin Side */}
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="panel" element={<AdminPanel />} />
          <Route path="banners" element={<AdminBanners />} />
          <Route path="logout" element={<AdminLogout />} />
        </Route>

        {/* 404 Page */}
        <Route path="*" element={<div className="text-center text-2xl p-10">404 - Page Not Found</div>} />
      </Routes>
    </Router>
  );
}

export default App;